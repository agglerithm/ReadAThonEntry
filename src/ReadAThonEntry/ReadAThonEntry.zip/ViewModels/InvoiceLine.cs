namespace TimeKeeper.ViewModels
{
    public class InvoiceLine
    {
        public string Department { get; set; }
        public decimal Hours { get; set; }
        public decimal Amount { get; set; }

    }
}